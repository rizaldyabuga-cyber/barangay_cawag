<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// Resident Statistics
$totalResidents = $conn->query("SELECT COUNT(*) FROM residents")->fetch_row()[0];
$maleResidents = $conn->query("SELECT COUNT(*) FROM residents WHERE gender='Male'")->fetch_row()[0];
$femaleResidents = $conn->query("SELECT COUNT(*) FROM residents WHERE gender='Female'")->fetch_row()[0];

// Certificate Statistics
$totalCertificates = $conn->query("SELECT COUNT(*) FROM certificates")->fetch_row()[0];

// Incident Statistics
$totalIncidents = $conn->query("SELECT COUNT(*) FROM barangay_records")->fetch_row()[0];
$ongoingCases = $conn->query("SELECT COUNT(*) FROM barangay_records WHERE status='Ongoing'")->fetch_row()[0];
$closedCases = $conn->query("SELECT COUNT(*) FROM barangay_records WHERE status='Closed'")->fetch_row()[0];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reports</title>

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins',sans-serif;
        }

        body{
            background:#f4f6f9;
            padding:30px;
        }

        .container{
            max-width:1000px;
            margin:auto;
            background:#fff;
            padding:30px;
            border-radius:15px;
            box-shadow:0 10px 30px rgba(0,0,0,.1);
        }

        h2{
            color:#2c3e50;
            margin-bottom:25px;
        }

        .btn{
            display:block;
            width:100%;
            margin:15px 0;
            padding:15px;
            background:#3498db;
            color:#fff;
            text-decoration:none;
            text-align:center;
            border-radius:8px;
            font-size:18px;
            transition:.3s;
        }

        .btn:hover{
            background:#2980b9;
        }

        .back{
            background:#2c3e50;
        }

        .back:hover{
            background:#1a252f;
        }
    </style>

</head>
<body>

<div class="container">

    <h2>Barangay Reports</h2>

    <a href="print_residents.php" class="btn">
        📋 Resident Master List
    </a>

    <a href="print_male_resident.php" class="btn">
        👨 Male Residents
    </a>

    <a href="print_female_resident.php" class="btn">
        👩 Female Residents
    </a>

    <a href="print_certificate_report.php" class="btn">
        📄 Certificates Report
    </a>

    <a href="print_incident_report.php" class="btn">
        🚨 Incident Records
    </a>

    <a href="dashboard.php" class="btn back">
        ← Back to Dashboard
    </a>

</div>

</body>
</html>