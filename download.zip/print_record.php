<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Record ID not found.");
}

$id = intval($_GET['id']);

$stmt = $conn->prepare("
    SELECT br.*, r.full_name, r.gender, r.birth_date, r.address
    FROM barangay_records br
    LEFT JOIN residents r ON br.resident_id = r.id
    WHERE br.id = ?
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Record not found.");
}

$record = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Barangay Record</title>

<style>

body{
    font-family:"Times New Roman",serif;
    margin:40px;
    color:#000;
}

.container{
    width:850px;
    margin:auto;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    width:90px;
    height:90px;
    object-fit:contain;
}

.title{
    flex:1;
    text-align:center;
}

.title p{
    margin:2px;
}

.title h2{
    margin:5px;
}

hr{
    border:1px solid black;
    margin-top:15px;
}

.report-title{

    text-align:center;
    margin:35px 0;

    font-size:28px;
    font-weight:bold;
    text-decoration:underline;

}

.info-table{

    width:100%;
    border-collapse:collapse;

}

.info-table td{

    border:1px solid black;
    padding:10px;
    vertical-align:top;

}

.label{

    width:220px;
    font-weight:bold;
    background:#f2f2f2;

}

.description{

    margin-top:35px;
    line-height:2;
    text-align:justify;
    font-size:17px;

}

.footer{

    margin-top:80px;

}

.signature{

    width:300px;
    float:right;
    text-align:center;

}

.secretary{

    width:300px;
    text-align:center;
    margin-top:120px;

}

.print-btn{

    padding:12px 25px;
    border:none;
    background:#27ae60;
    color:white;
    cursor:pointer;
    border-radius:6px;

}

.back-btn{

    padding:12px 25px;
    background:#2c3e50;
    color:white;
    text-decoration:none;
    border-radius:6px;
    margin-left:10px;

}

@media print{

.print-btn,
.back-btn{

display:none;

}

}

</style>

</head>

<body>

<button class="print-btn" onclick="window.print()">
🖨 Print
</button>

<a href="barangay_record.php" class="back-btn">
← Back
</a>

<div class="container">

<div class="header">

<?php if(!empty($system['logo'])){ ?>

<img src="<?= $system['logo']; ?>" class="logo">

<?php } ?>

<div class="title">

<p><strong>Republic of the Philippines</strong></p>

<p>Province of <?= htmlspecialchars($system['province']); ?></p>

<p>Municipality of <?= htmlspecialchars($system['municipality']); ?></p>

<h2><?= strtoupper($system['barangay_name']); ?></h2>

</div>

<?php if(!empty($system['logo'])){ ?>

<img src="<?= $system['logo']; ?>" class="logo">

<?php } ?>

</div>

<hr>

<div class="report-title">

BARANGAY RECORD

</div>

<table class="info-table">

<tr>

<td class="label">Record ID</td>

<td><?= $record['id']; ?></td>

</tr>

<tr>

<td class="label">Resident Name</td>

<td><?= htmlspecialchars($record['full_name']); ?></td>

</tr>

<tr>

<td class="label">Gender</td>

<td><?= htmlspecialchars($record['gender']); ?></td>

</tr>

<tr>

<td class="label">Birth Date</td>

<td><?= date("F d, Y",strtotime($record['birth_date'])); ?></td>

</tr>

<tr>

<td class="label">Address</td>

<td><?= htmlspecialchars($record['address']); ?></td>

</tr>

<tr>

<td class="label">Record Type</td>

<td><?= htmlspecialchars($record['record_type']); ?></td>

</tr>

<tr>

<td class="label">Date Recorded</td>

<td><?= date("F d, Y",strtotime($record['date_recorded'])); ?></td>

</tr>

<tr>

<td class="label">Status</td>

<td><?= htmlspecialchars($record['status']); ?></td>

</tr>

</table>

<div class="description">

<strong>Description:</strong>

<br><br>

<?= nl2br(htmlspecialchars($record['description'])); ?>

</div>

<div class="footer">

<div class="signature">

<b><?= strtoupper($system['captain_name']); ?></b>

<br>

Barangay Captain

</div>

<div class="secretary">

____________________________

<br>

<b><?= strtoupper($system['secretary_name']); ?></b>

<br>

Barangay Secretary

</div>

</div>

</div>

</body>
</html>