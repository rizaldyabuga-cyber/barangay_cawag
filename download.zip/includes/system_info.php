<?php

if (!isset($conn)) {
    include __DIR__ . "/../db_connect.php";
}

$result = $conn->query("SELECT * FROM system_settings WHERE id = 1");

if ($result && $result->num_rows > 0) {

    $system = $result->fetch_assoc();

} else {

    $system = [];

}

?>