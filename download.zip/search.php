<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$search = "";

if(isset($_GET['q'])){

    $search = trim($_GET['q']);

}

if($search == ""){

    die("
    <script>
    alert('Please enter a search keyword.');
    window.location='dashboard.php';
    </script>
    ");

}

?>

<!DOCTYPE html>
<html>
<head>

<title>Search Results</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{

    min-height:100vh;
    background:url('image/cawag.jpg') no-repeat center center fixed;
    background-size:cover;

}

body::before{

    content:"";
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    z-index:-1;

}


.container{

    max-width:1200px;
    margin:40px auto;
    padding:30px;

}


.header{

    display:flex;
    justify-content:space-between;
    align-items:center;
    color:white;
    margin-bottom:30px;

}


.back{

    background:#2c3e50;
    color:white;
    text-decoration:none;
    padding:10px 20px;
    border-radius:25px;

}


.box{

    background:rgba(255,255,255,.15);
    backdrop-filter:blur(15px);
    padding:25px;
    border-radius:20px;
    margin-bottom:25px;
    color:white;
    box-shadow:0 10px 30px rgba(0,0,0,.3);

}


.box h3{

    margin-bottom:20px;

}


.result{

    background:rgba(255,255,255,.12);
    padding:15px;
    border-radius:10px;
    margin-bottom:10px;

}


.result a{

    float:right;
    background:#27ae60;
    color:white;
    text-decoration:none;
    padding:7px 15px;
    border-radius:20px;

}


.result a:hover{

    background:#219150;

}


.none{

    color:#ddd;

}
    
    mark{

    background:#f1c40f;
    color:#000;
    padding:2px 5px;
    border-radius:5px;

}

.count{

    margin-top:10px;
    color:#ddd;
    font-size:15px;

}

.result a{

    float:right;
    background:#27ae60;
    color:white;
    text-decoration:none;
    padding:8px 15px;
    border-radius:20px;
    font-size:13px;

}


</style>

</head>

<body>


<div class="container">


<div class="header">

<h2>
Search Results for:
<?= htmlspecialchars($search); ?>
</h2>

<p class="count">
Searching the entire system...
</p>


<a href="dashboard.php" class="back">
← Dashboard
</a>


</div>



<?php


/* =====================
   RESIDENTS
===================== */


$residents = $conn->prepare("
SELECT *
FROM residents
WHERE full_name LIKE ?
OR contact_number LIKE ?
OR address LIKE ?
");

$like = "%".$search."%";

$residents->bind_param(
"sss",
$like,
$like,
$like
);

$residents->execute();

$resident_result = $residents->get_result();


?>


<div class="box">

<h3>👥 Residents</h3>


<?php

if($resident_result->num_rows > 0){

while($row=$resident_result->fetch_assoc()){

?>


<div class="result">

<b>
<?= htmlspecialchars($row['full_name']); ?>
</b>

<br>

<?= htmlspecialchars($row['address']); ?>


<a href="view_resident.php?id=<?= $row['id']; ?>">
👤 Open Resident
</a>

</div>


<?php

}

}else{

echo "<p class='none'>No resident found.</p>";

}

?>


</div>





<?php

/* =====================
   CERTIFICATES
===================== */


$certificates=$conn->prepare("
SELECT *
FROM certificates
WHERE resident_name LIKE ?
OR certificate_type LIKE ?
OR control_no LIKE ?
");


$certificates->bind_param(
"sss",
$like,
$like,
$like
);


$certificates->execute();

$certificate_result=$certificates->get_result();


?>


<div class="box">


<h3>📄 Certificates</h3>


<?php


if($certificate_result->num_rows > 0){


while($row=$certificate_result->fetch_assoc()){


?>


<div class="result">


<b>
<?= htmlspecialchars($row['certificate_type']); ?>
</b>

<br>

Resident:
<?= htmlspecialchars($row['resident_name']); ?>


<a href="print_certificate.php?id=<?= $row['id']; ?>">
📄 Print Certificate
</a>


</div>


<?php

}


}else{


echo "<p class='none'>No certificate found.</p>";


}


?>


</div>






<?php


/* =====================
 INCIDENT RECORDS
===================== */


$records=$conn->prepare("
SELECT *
FROM barangay_records
WHERE record_type LIKE ?
OR description LIKE ?
");


$records->bind_param(
"ss",
$like,
$like
);


$records->execute();

$record_result=$records->get_result();


?>


<div class="box">


<h3>🚨 Incident Records</h3>


<?php


if($record_result->num_rows > 0){


while($row=$record_result->fetch_assoc()){


?>


<div class="result">


<b>
<?= htmlspecialchars($row['record_type']); ?>
</b>

<br>

<?= htmlspecialchars($row['description']); ?>


<a href="print_record.php?id=<?= $row['id']; ?>">
🚨 Open Record
</a>


</div>


<?php

}


}else{


echo "<p class='none'>No incident record found.</p>";


}


?>


</div>







<?php

/* =====================
 ANNOUNCEMENTS
===================== */


$announcements=$conn->prepare("
SELECT *
FROM announcements
WHERE title LIKE ?
OR message LIKE ?
");


$announcements->bind_param(
"ss",
$like,
$like
);


$announcements->execute();

$announcement_result=$announcements->get_result();


?>


<div class="box">


<h3>📢 Announcements</h3>


<?php


if($announcement_result->num_rows > 0){


while($row=$announcement_result->fetch_assoc()){


?>


<div class="result">


<b>
<?= htmlspecialchars($row['title']); ?>
</b>

<br>

<?= htmlspecialchars(substr($row['message'],0,100)); ?>


<a href="announcements.php">
📢 Open Announcement
</a>

</div>


<?php

}


}else{


echo "<p class='none'>No announcement found.</p>";


}


?>


</div>



</div>


</body>
</html>