<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include "db_connect.php";
include "../includes/system_info.php";

if (!isset($_GET['id'])) {
    die("Certificate ID not found.");
}

$id = intval($_GET['id']);

$stmt = $conn->prepare("
SELECT c.*, r.full_name, r.address
FROM certificates c
LEFT JOIN residents r
ON c.resident_id = r.id
WHERE c.id=?
");

$stmt->bind_param("i",$id);
$stmt->execute();

$result=$stmt->get_result();

if($result->num_rows==0){
    die("Certificate not found.");
}

$certificate=$result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Print Certificate</title>

<style>

body{
    font-family:"Times New Roman",serif;
    margin:40px;
    color:#000;
}

.container{
    width:850px;
    margin:auto;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    width:90px;
    height:90px;
    object-fit:contain;
}

.title{
    flex:1;
    text-align:center;
}

.title h2{
    margin:5px;
}

.title p{
    margin:2px;
}

hr{
    margin-top:15px;
    border:1px solid black;
}

.certificate-title{

    text-align:center;
    margin-top:35px;
    margin-bottom:35px;

    font-size:30px;
    font-weight:bold;
    letter-spacing:2px;
    text-decoration:underline;

}

.content{

    margin-top:30px;
    font-size:19px;
    line-height:2.2;
    text-align:justify;

}

.footer{

    margin-top:80px;

}

.signature{

    width:320px;
    float:right;
    text-align:center;

}

.signature b{

    text-transform:uppercase;
    font-size:18px;

}

.secretary{

    margin-top:130px;
    width:320px;
    text-align:center;

}

.control{

    margin-top:40px;
    font-size:16px;

}

.print-btn{

    padding:12px 25px;
    background:#27ae60;
    color:white;
    border:none;
    cursor:pointer;
    border-radius:6px;
    margin-bottom:25px;

}

.back-btn{

    padding:12px 25px;
    background:#2c3e50;
    color:white;
    text-decoration:none;
    border-radius:6px;
    margin-left:10px;

}

@media print{

.print-btn,
.back-btn{

display:none;

}

}

</style>

</head>

<body>

<button class="print-btn" onclick="window.print()">
🖨 Print
</button>

<a href="certificates.php" class="back-btn">
← Back
</a>

<div class="container">

<div class="header">

<?php if (!empty($system['logo'])) { ?>
    <img src="<?= htmlspecialchars($system['logo']); ?>" class="logo">
<?php } ?>

<div class="title">

<p><b>Republic of the Philippines</b></p>

<p>Province of <?= htmlspecialchars($system['province']); ?></p>

<p>Municipality of <?= htmlspecialchars($system['municipality']); ?></p>

<h2><?= strtoupper($system['barangay_name']); ?></h2>

</div>

<?php if(!empty($system['logo'])){ ?>

<img src="<?= $system['logo']; ?>" class="logo">

<?php } ?>

</div>

<hr>

<div class="certificate-title">

<?= strtoupper($certificate['certificate_type']); ?>

</div>

<div class="content">

<p>

TO WHOM IT MAY CONCERN:

</p>

<p>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

This is to certify that

<b><?= strtoupper($certificate['resident_name']); ?></b>,

a resident of

<b><?= htmlspecialchars($certificate['address']); ?></b>,

Barangay <?= htmlspecialchars($system['barangay_name']); ?>,

<?= htmlspecialchars($system['municipality']); ?>,

<?= htmlspecialchars($system['province']); ?>,

is personally known to this office.

</p>

<p>

This certification is issued upon the request of the above-named person for

<b><?= strtoupper($certificate['purpose']); ?></b>

and for whatever legal purpose it may serve.

</p>

<p>

Issued this

<b><?= date("F d, Y",strtotime($certificate['date_issued'])); ?></b>

at Barangay

<b><?= htmlspecialchars($system['barangay_name']); ?></b>.

</p>

<div class="control">

Control No.:

<b><?= htmlspecialchars($certificate['control_no']); ?></b>

</div>

</div>

<div class="footer">

<div class="signature">

<b>

<?= strtoupper($system['captain_name']); ?>

</b>

<br>

Barangay Captain

</div>

<div class="secretary">

___________________________

<br>

<b>

<?= strtoupper($system['secretary_name']); ?>

</b>

<br>

Barangay Secretary

</div>

</div>

</div>

</body>
</html>