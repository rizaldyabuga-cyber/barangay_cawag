<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['role'] != 'admin') {
    die("Access Denied");
}

include "../db_connect.php";

$message = "";

// Get current settings
$result = $conn->query("SELECT * FROM system_settings WHERE id = 1");
$settings = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $barangay_name   = trim($_POST['barangay_name']);
    $municipality    = trim($_POST['municipality']);
    $province        = trim($_POST['province']);
    $captain_name    = trim($_POST['captain_name']);
    $secretary_name  = trim($_POST['secretary_name']);
    $treasurer_name  = trim($_POST['treasurer_name']);
    $contact_number  = trim($_POST['contact_number']);
    $email           = trim($_POST['email']);
    $system_name     = trim($_POST['system_name']);

    // Keep existing logo
    $logo = $settings['logo'];

    // Upload new logo
    if (!empty($_FILES['logo']['name'])) {

        $folder = "../uploads/logo/";

        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }

        $filename = time() . "_" . basename($_FILES["logo"]["name"]);
        $target = $folder . $filename;

       if (move_uploaded_file($_FILES["logo"]["tmp_name"], $target)) {
    $logo = "uploads/logo/" . $filename;
}
    }

    $stmt = $conn->prepare("
        UPDATE system_settings
        SET
            barangay_name=?,
            municipality=?,
            province=?,
            captain_name=?,
            secretary_name=?,
            treasurer_name=?,
            contact_number=?,
            email=?,
            system_name=?,
            logo=?
        WHERE id=1
    ");

    $stmt->bind_param(
        "ssssssssss",
        $barangay_name,
        $municipality,
        $province,
        $captain_name,
        $secretary_name,
        $treasurer_name,
        $contact_number,
        $email,
        $system_name,
        $logo
    );

    if ($stmt->execute()) {

        $message = "Settings updated successfully.";

        // Reload updated data
        $result = $conn->query("SELECT * FROM system_settings WHERE id=1");
        $settings = $result->fetch_assoc();

    } else {

        $message = "Failed to update settings.";

    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>System Settings</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    min-height:100vh;
    background:url('../image/cawag.jpg') no-repeat center center fixed;
    background-size:cover;
    display:flex;
    justify-content:center;
    align-items:center;
}

body::before{
    content:"";
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    z-index:-1;
}

.container{

    width:700px;
    background:rgba(255,255,255,.15);
    backdrop-filter:blur(15px);
    border-radius:20px;
    padding:35px;
    color:white;
    box-shadow:0 20px 40px rgba(0,0,0,.35);

}

h2{

    text-align:center;
    margin-bottom:25px;

}

.success{

    background:#4CAF50;
    padding:12px;
    border-radius:8px;
    margin-bottom:20px;
    text-align:center;

}

label{

    display:block;
    margin-top:15px;
    margin-bottom:6px;
    font-weight:500;

}

input{

    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    outline:none;
    font-size:14px;

}

input[type=file]{

    background:white;

}

.logo-preview{

    text-align:center;
    margin-top:20px;

}

.logo-preview img{

    width:120px;
    height:120px;
    object-fit:cover;
    border-radius:10px;
    border:3px solid white;

}

.buttons{

    margin-top:30px;
    display:flex;
    justify-content:space-between;

}

.save{

    background:#27ae60;
    color:white;
    border:none;
    padding:14px 30px;
    border-radius:30px;
    cursor:pointer;
    font-size:15px;

}

.save:hover{

    background:#219150;

}

.back{

    text-decoration:none;
    background:#2c3e50;
    color:white;
    padding:14px 30px;
    border-radius:30px;

}

.back:hover{

    background:#1f2d3a;

}

</style>

</head>

<body>

<div class="container">

<h2>System Settings</h2>

<?php if($message!=""){ ?>

<div class="success">

<?= $message ?>

</div>

<?php } ?>

<form method="POST" enctype="multipart/form-data">

<label>System Name</label>

<input
type="text"
name="system_name"
value="<?= htmlspecialchars($settings['system_name']) ?>"
required>

<label>Barangay Name</label>

<input
type="text"
name="barangay_name"
value="<?= htmlspecialchars($settings['barangay_name']) ?>"
required>

<label>Municipality</label>

<input
type="text"
name="municipality"
value="<?= htmlspecialchars($settings['municipality']) ?>"
required>

<label>Province</label>

<input
type="text"
name="province"
value="<?= htmlspecialchars($settings['province']) ?>"
required>

<label>Barangay Captain</label>

<input
type="text"
name="captain_name"
value="<?= htmlspecialchars($settings['captain_name']) ?>"
required>

<label>Barangay Secretary</label>

<input
type="text"
name="secretary_name"
value="<?= htmlspecialchars($settings['secretary_name']) ?>"
required>

<label>Barangay Treasurer</label>

<input
type="text"
name="treasurer_name"
value="<?= htmlspecialchars($settings['treasurer_name']) ?>"
required>

<label>Contact Number</label>

<input
type="text"
name="contact_number"
value="<?= htmlspecialchars($settings['contact_number']) ?>"
required>

<label>Email Address</label>

<input
type="email"
name="email"
value="<?= htmlspecialchars($settings['email']) ?>"
required>

<label>Barangay Logo</label>

<input
type="file"
name="logo"
accept="image/*">

<div class="logo-preview">

<?php
if(!empty($settings['logo'])){
?>

<img src="../<?= htmlspecialchars($settings['logo']); ?>">

<?php
}else{
?>

<p>No logo uploaded.</p>

<?php
}
?>

</div>

<div class="buttons">

<button class="save" type="submit">

💾 Save Changes

</button>

<a href="index.php" class="back">

← Back

</a>

</div>

</form>

</div>

</body>
</html>