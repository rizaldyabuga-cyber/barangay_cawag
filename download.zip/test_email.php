<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require "send_otp_api.php";

$email = "barangaycawagsystem@gmail.com";

$otp = rand(100000,999999);

if(sendOTP($email,$otp)){
    echo "Email Sent!";
}else{
    echo "Failed!";
}