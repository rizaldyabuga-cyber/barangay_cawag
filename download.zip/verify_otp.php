<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['reset_email'])) {
    header("Location: forgot_password.php");
    exit();
}

$message = "";

if (isset($_POST['verify'])) {

    $email = $_SESSION['reset_email'];
    $otp = trim($_POST['otp']);

    $stmt = $conn->prepare("
        SELECT *
        FROM password_resets
        WHERE email=? AND otp=? AND expires_at > NOW()
    ");

    $stmt->bind_param("ss", $email, $otp);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows == 1) {

        $_SESSION['otp_verified'] = true;

        header("Location: reset_password.php");
        exit();

    } else {

        $message = "Invalid or expired OTP.";

    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Verify OTP</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:url('image/cawag.jpg') no-repeat center center fixed;
    background-size:cover;
}

body::before{
    content:"";
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
}

.form-box{
    position:relative;
    z-index:1;
    width:420px;
    background:rgba(255,255,255,.15);
    backdrop-filter:blur(15px);
    padding:40px;
    border-radius:20px;
    color:white;
    box-shadow:0 20px 40px rgba(0,0,0,.4);
}

h2{
    text-align:center;
    margin-bottom:20px;
}

input{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    margin:15px 0;
}

button{
    width:100%;
    padding:12px;
    border:none;
    border-radius:30px;
    background:#4CAF50;
    color:white;
    cursor:pointer;
    font-size:16px;
}

button:hover{
    background:#43a047;
}

.message{
    color:#ffb3b3;
    margin-bottom:15px;
    text-align:center;
}

</style>

</head>
<body>

<div class="form-box">

<h2>Verify OTP</h2>

<?php
if($message){
    echo "<div class='message'>$message</div>";
}
?>

<form method="POST">

<input
type="text"
name="otp"
placeholder="Enter 6-digit OTP"
maxlength="6"
required>

<button
type="submit"
name="verify">
Verify OTP
</button>

</form>

</div>

</body>
</html>