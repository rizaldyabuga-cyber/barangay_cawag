<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['reset_email']) || !isset($_SESSION['otp_verified'])) {
    header("Location: forgot_password.php");
    exit();
}

$message = "";

if (isset($_POST['reset'])) {

    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if ($password != $confirm) {

        $message = "Passwords do not match.";

    } else {

        $email = $_SESSION['reset_email'];

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("
            UPDATE admins
            SET password=?
            WHERE email=?
        ");

        $stmt->bind_param("ss", $hashedPassword, $email);

        if ($stmt->execute()) {

            // Delete used OTP
            $delete = $conn->prepare("
                DELETE FROM password_resets
                WHERE email=?
            ");

            $delete->bind_param("s", $email);
            $delete->execute();

            // Destroy reset session
            unset($_SESSION['reset_email']);
            unset($_SESSION['otp_verified']);

            echo "<script>
                alert('Password has been reset successfully.');
                window.location='login.php';
            </script>";

            exit();

        } else {

            $message = "Failed to update password.";

        }

    }

}
?>
<!DOCTYPE html>
<html>
<head>

<title>Reset Password</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;
}

body{
min-height:100vh;
display:flex;
justify-content:center;
align-items:center;
background:url('image/cawag.jpg') no-repeat center center fixed;
background-size:cover;
}

body::before{
content:"";
position:fixed;
inset:0;
background:rgba(0,0,0,.45);
}

.form-box{
position:relative;
z-index:1;
width:420px;
padding:40px;
border-radius:20px;
background:rgba(255,255,255,.15);
backdrop-filter:blur(15px);
color:white;
box-shadow:0 20px 40px rgba(0,0,0,.4);
}

h2{
text-align:center;
margin-bottom:20px;
}

input{
width:100%;
padding:12px;
margin:15px 0;
border:none;
border-radius:10px;
}

button{
width:100%;
padding:12px;
border:none;
border-radius:30px;
background:#4CAF50;
color:white;
font-size:16px;
cursor:pointer;
}

button:hover{
background:#43a047;
}

.message{
color:#ffb3b3;
margin-bottom:15px;
text-align:center;
}

</style>

</head>
<body>

<div class="form-box">

<h2>Reset Password</h2>

<?php
if($message){
echo "<div class='message'>$message</div>";
}
?>

<form method="POST">

<input
type="password"
name="password"
placeholder="New Password"
required>

<input
type="password"
name="confirm_password"
placeholder="Confirm Password"
required>

<button
type="submit"
name="reset">
Reset Password
</button>

</form>

</div>

</body>
</html>