<?php
    session_start();

header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include "db_connect.php";


$search = "";
$gender = "";
$address = "";


if(isset($_GET['search'])){
    $search = $_GET['search'];
}

if(isset($_GET['gender'])){
    $gender = $_GET['gender'];
}

if(isset($_GET['address'])){
    $address = $_GET['address'];
}



$sql = "SELECT * FROM residents WHERE 1=1";


if($search != ""){

    $search = $conn->real_escape_string($search);

    $sql .= "
    AND (
        full_name LIKE '%$search%'
        OR contact_number LIKE '%$search%'
        OR address LIKE '%$search%'
    )
    ";

}


if($gender != ""){

    $gender = $conn->real_escape_string($gender);

    $sql .= " AND gender='$gender' ";

}


if($address != ""){

    $address = $conn->real_escape_string($address);

    $sql .= " AND address LIKE '%$address%' ";

}


$sql .= " ORDER BY created_at DESC";


$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Registered Residents</title>
    <style>
       *{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f4f6f9;
    padding:30px;
}

/* Main Container */
.container{
    max-width:1300px;
    margin:auto;
    background:#fff;
    border-radius:15px;
    box-shadow:0 10px 30px rgba(0,0,0,.1);
    padding:30px;
}

/* Header */
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.header h2{
    color:#2c3e50;
    font-size:28px;
}

/* Back Button */
.back-btn{
    background:#2c3e50;
    color:#fff;
    text-decoration:none;
    padding:10px 18px;
    border-radius:8px;
    transition:.3s;
    font-size:14px;
}

.back-btn:hover{
    background:#1a252f;
}
        
        .btn-add{
    background:#27ae60;
    color:#fff;
    padding:10px 18px;
    text-decoration:none;
    border-radius:8px;
    display:inline-block;
    margin-bottom:20px;
    transition:.3s;
}

.btn-add:hover{
    background:#219150;
}

/* Table */
table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:10px;
}

table th{
    background:#3498db;
    color:#fff;
    padding:15px;
    text-align:left;
}

table td{
    padding:15px;
    border-bottom:1px solid #eee;
}

table tr:nth-child(even){
    background:#f8f9fa;
}

table tr:hover{
    background:#eef6ff;
}

/* Buttons */
.btn{
    display:inline-block;
    padding:8px 14px;
    border-radius:6px;
    color:#fff;
    text-decoration:none;
    font-size:13px;
    margin:2px;
    transition:.3s;
}

.btn-edit{
    background:#3498db;
}

.btn-edit:hover{
    background:#2980b9;
}

.btn-delete{
    background:#e74c3c;
}

.btn-delete:hover{
    background:#c0392b;
}
        
        .filter-box{

    display:flex;
    gap:10px;
    margin-bottom:25px;
    flex-wrap:wrap;

}


.filter-box input,
.filter-box select{

    padding:10px 15px;
    border:1px solid #ddd;
    border-radius:8px;
    outline:none;
    font-size:14px;

}


.filter-btn{

    background:#27ae60;
    color:white;
    border:none;
    padding:10px 20px;
    border-radius:8px;
    cursor:pointer;

}


.filter-btn:hover{

    background:#219150;

}


.reset-btn{

    background:#e74c3c;
    color:white;
    padding:10px 20px;
    border-radius:8px;
    text-decoration:none;

}


.reset-btn:hover{

    background:#c0392b;

}
        
.filter-container{
    width:100%;
    margin-bottom:25px;
    display:flex;
    justify-content:flex-end;
}

.filter-container form{
    display:flex;
    gap:10px;
    flex-wrap:wrap;
}

.filter-container input,
.filter-container select{
    padding:10px;
    border:1px solid #ddd;
    border-radius:8px;
}

.filter-container button{
    background:#27ae60;
    color:white;
    border:none;
    padding:10px 20px;
    border-radius:8px;
    cursor:pointer;
}

.filter-container a{
    background:#e74c3c;
    color:white;
    text-decoration:none;
    padding:10px 20px;
    border-radius:8px;
}
        
        
    </style>
</head>
<body>

<!-- BACK TO DASHBOARD BUTTON -->
<div class="header">

    <h2>Registered Residents</h2>

    <a href="dashboard.php" class="back-btn">
        ← Back to Dashboard
    </a>

</div>
    
  <a href="add_resident.php" class="btn btn-add">
    + Add Resident
</a>
    
    <div class="filter-container">       
        
<form method="GET">
    
<input 
type="text"
name="search"
placeholder="Search name, contact, address..."
value="<?= htmlspecialchars($search ?? '') ?>">


<select name="gender">

<option value="">All Gender</option>

<option value="Male">
Male
</option>

<option value="Female">
Female
</option>

</select>


<input 
type="text"
name="address"
placeholder="Address"
value="<?= htmlspecialchars($address ?? '') ?>">


<button type="submit">
Search
</button>


<a href="residents.php">
Reset
</a>


</form>

</div>
    
    <table>
    <tr>
        <th>ID</th>
        <th>Full Name</th>
        <th>Gender</th>
        <th>Birth Date</th>
        <th>Contact</th>
        <th>Address</th>
        <th>Email</th>
        <th>Actions</th>
    </tr>

    <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['full_name']) ?></td>
            <td><?= $row['gender'] ?></td>
            <td><?= $row['birth_date'] ?></td>
            <td><?= $row['contact_number'] ?></td>
            <td><?= htmlspecialchars($row['address']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td>
                <a class="btn btn-edit" href="edit_resident.php?id=<?= $row['id'] ?>">Edit</a>
                <a class="btn btn-delete" href="delete_resident.php?id=<?= $row['id'] ?>"
                   onclick="return confirm('Are you sure you want to delete this resident?');">
                   Delete
                </a>
                <a class="btn btn-edit" href="view_resident.php?id=<?= $row['id'] ?>">View</a>
            </td>
        </tr>
    <?php endwhile; ?>
        
</table>
    </div>
</body>
</html>
