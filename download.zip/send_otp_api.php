<?php

function sendOTP($toEmail, $otp)
{
    $apiKey = "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";

    $data = [
        "sender" => [
            "name" => "Barangay Cawag Management System",
            "email" => "barangaycawagsystem@gmail.com"
        ],
        "to" => [
            [
                "email" => $toEmail
            ]
        ],
        "subject" => "Password Reset OTP",
        "htmlContent" => "
            <h2>Barangay Cawag Management System</h2>

            <p>Your One-Time Password is:</p>

            <h1 style='color:#3498db;'>$otp</h1>

            <p>This OTP will expire in 10 minutes.</p>

            <p>If you did not request this password reset, please ignore this email.</p>
        "
    ];

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, "https://api.brevo.com/v3/smtp/email");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "accept: application/json",
        "api-key: " . $apiKey,
        "content-type: application/json"
    ]);

    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo curl_error($ch);
        return false;
    }

    curl_close($ch);

    return true;
}
?>